#include<iostream>
#include <cstring>
#include "linkedlist.h"
#define size_d 100
using namespace std;
class Queue
{
	public:
	Movie data[size_d];
	int front;
	int rear;
	Queue()
	{
		memset(data,0,sizeof data);
		front=0;
		rear=-1;
	}
	void push(Movie x)
	{
		data[++rear]=x;
	}
	void pop(){
		++front;
	}
	float peekfront()
	{
		return data[front].get_rating();
	}
	int size()
	{
		return size_d;
	}
};
class PriorityQueue{
	public:
		PriorityQueue(){
			
		}
		PriorityQueue(Queue q)
		{
			int min=getMin(q);
		}
		int getMin(Queue q)
		{
			int min=INT_MAX;
			int i=0;
			while(i!=q.size())
			{
				cout<<q.peekfront();
				i++;
				if(q.peekfront()<min)
				{
					min=q.peekfront();
				}
				q.push(q.data[i]);
				q.pop();
			}
			return min;
		}

};

