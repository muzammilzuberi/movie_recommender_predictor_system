#!/usr/bin/env python
# coding: utf-8

# In[72]:


import pandas as pd


# In[73]:


df=pd.read_csv("D:\Downloads\IMDB-Movie-Data.csv")


# In[74]:


df


# In[75]:


df["Votes"]=df["Votes"].fillna(method="pad",limit=10)


# In[76]:


df["Rating"].fillna(method="pad",limit=10)


# In[77]:


df["Metascore"]=df["Metascore"].fillna(method="pad",limit=10)


# In[78]:


df["Revenue (Millions)"]=df["Revenue (Millions)"].fillna(method="pad",limit=10)


# In[80]:


df["Year"]=df["Year"].fillna(method="pad",limit=10)


# In[81]:


df=df.fillna("Not avaialble")


# In[96]:


df.to_csv("D:\Downloads\Cleaned.csv",header=False,index=False)


# In[104]:


df["Description"]=df["Description"].replace(',', '', regex=True)


# In[107]:


df["Genre"]=df["Genre"].replace(',', ' ', regex=True)


# In[108]:


df["Actors"]=df["Actors"].replace(',', '', regex=True)


# In[109]:


df


# In[111]:


df.to_csv("D:\Downloads\Cleaned.csv",header=False,index=False)


# In[ ]:




