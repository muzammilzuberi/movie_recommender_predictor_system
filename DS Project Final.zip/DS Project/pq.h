#include <iostream>
#include <cstdio>
#include <cstring>
#include <cstdlib>
#include "linkedlist.h"
using namespace std;
struct PQNode 
{
   float priority;
   string info;
   struct PQNode *next;
};
class Priority_Queue {
   private:
     
      PQNode *front;
   public:
      Priority_Queue() 
      {
         front = NULL;
      }
      void insert(string str,float p) 
	  {
         PQNode *temp, *temp2;
         temp= new PQNode;
         temp->info=str;
         temp->priority=p;
         if (front == NULL || p >= front->priority) 
		 {
            temp->next=front;
            front=temp;
         } 
		 else 
		 {
            temp2=front;
            while (temp2->next != NULL && temp2->next->priority >= p)
               temp2 = temp2->next;
               
               temp->next = temp2->next;
               temp2->next = temp;
         }
      }
      bool empty()
	  {
      	if(front==NULL)
		  {
      		return true;
		  }
		  else
		  {
		  	return false;
		  }
	  }
      string get_front()
      {
      	
      	return front->info;
	  }
      void del() 
	  {
        PQNode *temp;
        if(front == NULL) 
        cout<<"Queue Underflow\n";
        
		else 
		 {
            temp = front;
//            cout<<"Deleted item is: "<<temp->info<<endl;
            front = front->next;
            free(temp);
         }
      }
//      void show() 
//	{
//		
//		PQNode *ptr;
//        ptr = front;
//        if (front == NULL)
//        cout<<"Queue is empty\n";
//        else
//		{
//            cout<<"Queue: ";
//            while(ptr != NULL) 
//			{
//               
//               ptr=ptr->next;
//            }
//         }
//      }
};


