#include <iostream>
#include <cstdio>
#include <cstring>
#include <cstdlib>
#include"movie.h"
using namespace std;
struct Node 
{
   int priority;
   Movie info;
   struct Node *next;
};
class Priority_Queue {
   private:
     
      Node *front;
   public:
      Priority_Queue() 
      {
         front = NULL;
      }
      void insert(Movie m,int p) 
	  {
         Node *temp, *temp2;
         temp= new Node;
         temp->info=m;
         temp->priority=p;
         if (front == NULL || p > front->priority) 
		 {
            temp->next=front;
            front=temp;
         } 
		 else 
		 {
            temp2=front;
            while (temp2->next != NULL && temp2->next->priority >= p)
               temp2 = temp2->next;
               
               temp->next = temp2->next;
               temp2->next = temp;
         }
      }
//      void del() 
//	  {
//        Node *temp;
//        if(front == NULL) 
//        cout<<"Queue Underflow\n";
//        
//		else 
//		 {
//            temp = front;
//            cout<<"Deleted item is: "<<temp->info<<endl;
//            front = front->next;
//            free(temp);
//         }
//      }
      void show() 
	{
		
		Node *ptr;
        ptr = front;
        if (front == NULL)
        cout<<"Queue is empty\n";
        else 
		{
            cout<<"Queue: ";
            while(ptr != NULL) 
			{
               ptr->info.display_details();
               ptr=ptr->next;
            }
         }
      }
};


