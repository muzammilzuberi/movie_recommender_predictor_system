#include<iostream>
#include<conio.h>
#include<windows.h>
#include<cstdlib>
#include <cwchar>
using namespace std;

class project_graphics
{
	public:
	static void start()
	{
		system("Color E2");
		char a=219;
		cout<<"\n\n\n\n\n\n\n\n\t\t   LOADING! \n";
		cout<<"\t\t\t  ";
		for(int i=0;i<=10;i++)
		{
			cout<<a;
			cout<<a;
			Sleep(50);
		}
		
		system("cls");
		cout<<"\n\n\n\n\n\n\n\n\t\t\t------------MOVIEGESSTION----------";
		cout<<"\n\n\n\t\t\tDesigned By:\n\n\t\t\tMohib-ur-Rehman\t\t19K-1364\t\t\t\t\n\t\t\tMohib Tariq\t\t19k-0310\t\t\t\t\t\n\t\t\tMuzammil Arif Zuberi\t19K-0342\n\n";
		cout<<"\t\t\t------------------------------------------------------"<<endl;
		cout<<"\t\t\t\t\tPress Any Key To Begin";
		getch();	
		system("Color E2");
		again:
		system("cls");

	}

};

